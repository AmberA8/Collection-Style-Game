//Move the catcher with the left and right arrow keys to catch the falling objects. 

/* VARIABLES */
let catcher, fallingObject;
let score = 0;
let backgroundImg, rocketImg, asteroidImg, explodeImg;
let level =1;

/* PRELOAD FILES */
function preload(){
  backgroundImg = loadImage("assets/background.jpg");
  rocketImg = loadImage("assets/catcher.png");
  asteroidImg = loadImage("assets/fallingobject.png");
  explodeImg = loadImage("assets/explode.png");
}

// SETUP RUNS ONCE 
function setup() {
  createCanvas(400,400);
  
  //Resizing images
  backgroundImg.resize(725,820);
  rocketImg.resize(35, 0); 
  asteroidImg.resize(120, 0);
 

  //Create catcher/rocket
  catcher = new Sprite(rocketImg, 200, 370, "k");
  catcher.color = color(95,158,160);
  
  //Create falling object
  fallingObject = new Sprite(asteroidImg,100,0);
  fallingObject.velocity.y = 2;
  fallingObject.rotationLock = true;
}

/* DRAW LOOP REPEATS */
function draw() {
  background(224,224,224);

  //Draw background image
  image(backgroundImg, 0, 0);

  if (level == 1) {
    level1Assets();
  }

  if (level == 2) {
    level2Assets();
  }
  
  
  // Draw directions to screen
  fill("white");
  textSize(12);
  text("Use the left and \n right arrow keys \n to  protect the \n Earth from the \n aestroids!", width-100, 20);

  //If Asteroid reaches bottom, move back randomly at the top
  if(fallingObject.y >= height){
    fallingObject.y = 0;
    fallingObject.x = random(50,350);
    fallingObject.vel.y = random(2,4);
    score = score - 1;
  }

  //Move catcher
  if(kb.pressing("left")) {
    catcher.vel.x = -3;
  } else if(kb.pressing("right")) {
    catcher.vel.x = +3;
  } else{
    catcher.vel.x = 0;
  }

  //Stops catcher at ends of screen
  if(catcher.x <50) {
    catcher.x = 50;
  } else if (catcher.x > 350) {
    catcher.x = 350
  }
  
  //When asteroid collides with rocket, move back randomly at the top
  if(fallingObject.collide(catcher)){
    fallingObject.y = 0;
    fallingObject.x = random(50,350);
    fallingObject.velocity.y = random(2,4);
    fallingObject.direction = "down";
    score = score + 1;
  }

  //Draw the score to screen
  fill('white');
  textSize(20);
  text("Score = " + score, 10, 60);

  // Draw level to screen
  fill('white');
  textSize(20);
  text("Level = " + level, 10, 30);

  //Check if the player beat level 1
  if (level == 1 && score == 5) {
    level = 2;
    score = 0;
    level2Assets();
  }
  
  //Lose Screen
  if(score < 0){
    playerLose();
  }

  //Check if player won
  if(level ==2 && score == 10) {
    playerWin();
  }
}

//FUNCTIONS
function level1Assets() {
 //Directions to screen
  fill('white');
  textSize(12);
  text("Block 5 asteroids \nto protect \n the Earth!", 100, 25);
}

function level2Assets() {
  //Directions to screen
  fill('white');
  textSize(12);
  text("Block 10 asteroids \nto protect \n the Earth!", 100, 25);
}

function playerWin(){
  catcher.pos = {x: 600, y: -300};
  fallingObject.pos = {x: -100, y: 0};

  //end of game text
  image(backgroundImg, 0, 0);
  textSize(20)
  fill('green')
  text("EARTH IS SAFE! YOU WIN! :) ", width/2-75, height/2)
  textSize(18)
  text("Press Anywhere to Play Again!", width/2-100, height/2+25);
  
  fallingObject.vel.x = 0;
  fallingObject.vel.y = 0;
  fallingObject.x = -100
  fallingObject.y = -100

  catcher.vel.x = 0
  catcher.x = -500
  catcher.y = -500
  if(mouseIsPressed){
    restart();
  }
}

function playerLose(){
  image(backgroundImg, 0, 0);
  textSize(20)
  fill('red')
  text("EARTH HAS BEEN DESTROYED! \n YOU LOSE :( ",20, 200)
  image(explodeImg, 170, 200, mouseX, 260)
  textSize(18)
  text("Press Anywhere to Play Again", 100, 300);
  fallingObject.vel.x = 0;
  fallingObject.vel.y = 0;
  fallingObject.x = -100
  fallingObject.y = -100
  catcher.vel.x = 0
  catcher.x = -500
  catcher.y = -500
  if(mouseIsPressed){
    restart()
  
  }
}

function restart(){
  score = 0;
  catcher.x = 200;
  catcher.y = 380;
  fallingObject.x = random(width);
  fallingObject.y = 0;

  fallingObject.vel.y = random(1,5);
  fallingObject.direction = 'down';
}
